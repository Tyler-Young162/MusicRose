let canvas, ctx;
let width, height;

// Parameters configuration
const params = {
    // Inner 4 circles - 根据用户给定的默认值
    innerCircles: [
        { radius: 0.15, offsetX: 0.02, offsetY: -0.02 },   // Circle 1: 15.0%, 2.00%, -2.00%
        { radius: 0.22, offsetX: 0.045, offsetY: 0.025 }, // Circle 2: 22.0%, 4.50%, 2.50%
        { radius: 0.31, offsetX: -0.035, offsetY: 0.025 }, // Circle 3: 31.0%, -3.50%, 2.50%
        { radius: 0.43, offsetX: 0.05, offsetY: 0.04 }   // Circle 4: 43.0%, 5.00%, 4.00%
    ],
    // Outer circle 5 (segmented petals)
    outerCircle5: {
        radius: 0.33,              // 33% as default
        segmentLength: 0.25,      // 25% of circle (can be adjusted to 30% etc)
        selfRotation: 0.12,        // Self-rotation angle (radians)
        globalRotation: 0,         // Global rotation angle (radians)
    },
    // Outer circle 6 (segmented petals)
    outerCircle6: {
        radius: 0.44,              // 44% as default
        segmentLength: 0.25,       // 25% of circle
        selfRotation: 0.12,        // Self-rotation angle (radians)
        globalRotation: 0.3927,    // ~22.5 degrees (Math.PI / 8)
    }
};

// Base configuration
const config = {
    maxRadius: 300,
    centerX: 0,
    centerY: 0,
};

function init() {
    canvas = document.getElementById('canvas');
    if (!canvas) {
        console.error('Canvas element not found!');
        return;
    }
    
    ctx = canvas.getContext('2d');
    if (!ctx) {
        console.error('Could not get 2D context!');
        return;
    }
    
    createControlPanel();
    resize();
    draw();
    console.log('Rose layout initialized successfully!');
}

function resize() {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
    config.centerX = width / 2;
    config.centerY = height / 2;
    config.maxRadius = Math.min(width, height) * 0.4;
}

window.addEventListener('resize', resize);

// Create control panel UI
function createControlPanel() {
    // Inner circles controls
    const innerControls = document.getElementById('innerCirclesControls');
    params.innerCircles.forEach((circle, index) => {
        const circleDiv = document.createElement('div');
        circleDiv.className = 'control-group';
        circleDiv.innerHTML = `
            <label>圆圈 ${index + 1} - 半径 (相对于最大半径):</label>
            <input type="range" id="innerR${index}" min="0.05" max="0.5" step="0.01" value="${circle.radius}">
            <span class="value-display" id="innerR${index}Value">${(circle.radius * 100).toFixed(1)}%</span>
            
            <label>圆圈 ${index + 1} - X偏移:</label>
            <input type="range" id="innerX${index}" min="-0.1" max="0.1" step="0.005" value="${circle.offsetX}">
            <span class="value-display" id="innerX${index}Value">${(circle.offsetX * 100).toFixed(2)}%</span>
            
            <label>圆圈 ${index + 1} - Y偏移:</label>
            <input type="range" id="innerY${index}" min="-0.1" max="0.1" step="0.005" value="${circle.offsetY}">
            <span class="value-display" id="innerY${index}Value">${(circle.offsetY * 100).toFixed(2)}%</span>
        `;
        innerControls.appendChild(circleDiv);
        
        // Add event listeners
        document.getElementById(`innerR${index}`).addEventListener('input', (e) => {
            params.innerCircles[index].radius = parseFloat(e.target.value);
            document.getElementById(`innerR${index}Value`).textContent = (params.innerCircles[index].radius * 100).toFixed(1) + '%';
            draw();
        });
        document.getElementById(`innerX${index}`).addEventListener('input', (e) => {
            params.innerCircles[index].offsetX = parseFloat(e.target.value);
            document.getElementById(`innerX${index}Value`).textContent = (params.innerCircles[index].offsetX * 100).toFixed(2) + '%';
            draw();
        });
        document.getElementById(`innerY${index}`).addEventListener('input', (e) => {
            params.innerCircles[index].offsetY = parseFloat(e.target.value);
            document.getElementById(`innerY${index}Value`).textContent = (params.innerCircles[index].offsetY * 100).toFixed(2) + '%';
            draw();
        });
    });
    
    // Outer circle 5 controls
    const outer5Controls = document.getElementById('outerCircle5Controls');
    outer5Controls.innerHTML = `
        <div class="control-group">
            <label>半径 (相对于最大半径):</label>
            <input type="range" id="outer5Radius" min="0.3" max="0.9" step="0.01" value="${params.outerCircle5.radius}">
            <span class="value-display" id="outer5RadiusValue">${(params.outerCircle5.radius * 100).toFixed(1)}%</span>
        </div>
        <div class="control-group">
            <label>每段长度 (占圆周百分比):</label>
            <input type="range" id="outer5Segment" min="0.15" max="0.4" step="0.01" value="${params.outerCircle5.segmentLength}">
            <span class="value-display" id="outer5SegmentValue">${(params.outerCircle5.segmentLength * 100).toFixed(1)}%</span>
        </div>
        <div class="control-group">
            <label>自旋角 (弧度):</label>
            <input type="range" id="outer5SelfRot" min="-0.5" max="0.5" step="0.01" value="${params.outerCircle5.selfRotation}">
            <span class="value-display" id="outer5SelfRotValue">${params.outerCircle5.selfRotation.toFixed(3)}</span>
        </div>
        <div class="control-group">
            <label>整体旋转角 (弧度):</label>
            <input type="range" id="outer5GlobalRot" min="0" max="6.28" step="0.01" value="${params.outerCircle5.globalRotation}">
            <span class="value-display" id="outer5GlobalRotValue">${params.outerCircle5.globalRotation.toFixed(3)}</span>
        </div>
    `;
    
    document.getElementById('outer5Radius').addEventListener('input', (e) => {
        params.outerCircle5.radius = parseFloat(e.target.value);
        document.getElementById('outer5RadiusValue').textContent = (params.outerCircle5.radius * 100).toFixed(1) + '%';
        draw();
    });
    document.getElementById('outer5Segment').addEventListener('input', (e) => {
        params.outerCircle5.segmentLength = parseFloat(e.target.value);
        document.getElementById('outer5SegmentValue').textContent = (params.outerCircle5.segmentLength * 100).toFixed(1) + '%';
        draw();
    });
    document.getElementById('outer5SelfRot').addEventListener('input', (e) => {
        params.outerCircle5.selfRotation = parseFloat(e.target.value);
        document.getElementById('outer5SelfRotValue').textContent = params.outerCircle5.selfRotation.toFixed(3);
        draw();
    });
    document.getElementById('outer5GlobalRot').addEventListener('input', (e) => {
        params.outerCircle5.globalRotation = parseFloat(e.target.value);
        document.getElementById('outer5GlobalRotValue').textContent = params.outerCircle5.globalRotation.toFixed(3);
        draw();
    });
    
    // Outer circle 6 controls
    const outer6Controls = document.getElementById('outerCircle6Controls');
    outer6Controls.innerHTML = `
        <div class="control-group">
            <label>半径 (相对于最大半径):</label>
            <input type="range" id="outer6Radius" min="0.3" max="0.9" step="0.01" value="${params.outerCircle6.radius}">
            <span class="value-display" id="outer6RadiusValue">${(params.outerCircle6.radius * 100).toFixed(1)}%</span>
        </div>
        <div class="control-group">
            <label>每段长度 (占圆周百分比):</label>
            <input type="range" id="outer6Segment" min="0.15" max="0.4" step="0.01" value="${params.outerCircle6.segmentLength}">
            <span class="value-display" id="outer6SegmentValue">${(params.outerCircle6.segmentLength * 100).toFixed(1)}%</span>
        </div>
        <div class="control-group">
            <label>自旋角 (弧度):</label>
            <input type="range" id="outer6SelfRot" min="-0.5" max="0.5" step="0.01" value="${params.outerCircle6.selfRotation}">
            <span class="value-display" id="outer6SelfRotValue">${params.outerCircle6.selfRotation.toFixed(3)}</span>
        </div>
        <div class="control-group">
            <label>整体旋转角 (弧度):</label>
            <input type="range" id="outer6GlobalRot" min="0" max="6.28" step="0.01" value="${params.outerCircle6.globalRotation}">
            <span class="value-display" id="outer6GlobalRotValue">${params.outerCircle6.globalRotation.toFixed(3)}</span>
        </div>
    `;
    
    document.getElementById('outer6Radius').addEventListener('input', (e) => {
        params.outerCircle6.radius = parseFloat(e.target.value);
        document.getElementById('outer6RadiusValue').textContent = (params.outerCircle6.radius * 100).toFixed(1) + '%';
        draw();
    });
    document.getElementById('outer6Segment').addEventListener('input', (e) => {
        params.outerCircle6.segmentLength = parseFloat(e.target.value);
        document.getElementById('outer6SegmentValue').textContent = (params.outerCircle6.segmentLength * 100).toFixed(1) + '%';
        draw();
    });
    document.getElementById('outer6SelfRot').addEventListener('input', (e) => {
        params.outerCircle6.selfRotation = parseFloat(e.target.value);
        document.getElementById('outer6SelfRotValue').textContent = params.outerCircle6.selfRotation.toFixed(3);
        draw();
    });
    document.getElementById('outer6GlobalRot').addEventListener('input', (e) => {
        params.outerCircle6.globalRotation = parseFloat(e.target.value);
        document.getElementById('outer6GlobalRotValue').textContent = params.outerCircle6.globalRotation.toFixed(3);
        draw();
    });
}

// Calculate positions for 4 nested circles using parameters
function calculateFourCircles() {
    const maxRadius = config.maxRadius * 0.5;
    const circles = [];
    
    params.innerCircles.forEach((circleParams, index) => {
        const radius = maxRadius * circleParams.radius;
        const offsetX = maxRadius * circleParams.offsetX;
        const offsetY = maxRadius * circleParams.offsetY;
        
        circles.push({
            cx: config.centerX + offsetX,
            cy: config.centerY + offsetY,
            radius: radius
        });
    });
    
    return circles;
}

// Draw a circle as line segments
function drawCircleOutline(cx, cy, radius, color = 'white') {
    ctx.strokeStyle = color;
    ctx.lineWidth = 1;
    ctx.beginPath();
    
    const segments = 120;
    for (let i = 0; i <= segments; i++) {
        const angle = (i / segments) * Math.PI * 2;
        const x = cx + Math.cos(angle) * radius;
        const y = cy + Math.sin(angle) * radius;
        
        if (i === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
    }
    
    ctx.stroke();
}

// Draw segmented circle with parameters
function drawSegmentedCircle(circleIndex, circleParams) {
    const numSegments = 4;
    const baseRadius = config.maxRadius * circleParams.radius;
    const segmentAngleSize = circleParams.segmentLength * Math.PI * 2; // Convert percentage to radians
    const gapSize = (Math.PI * 2 - segmentAngleSize * numSegments) / numSegments; // Calculate gap
    
    ctx.strokeStyle = circleIndex === 5 ? 'cyan' : 'yellow';
    ctx.lineWidth = 2;
    
    // Start from global rotation angle
    let currentAngle = circleParams.globalRotation;
    
    for (let i = 0; i < numSegments; i++) {
        // Calculate segment midpoint angle (the center point of this arc on the circle)
        const segmentMidAngle = currentAngle + segmentAngleSize * 0.5;
        
        // Calculate the center point of the arc on the circle (this is the rotation center for self-rotation)
        const centerX = config.centerX + Math.cos(segmentMidAngle) * baseRadius;
        const centerY = config.centerY + Math.sin(segmentMidAngle) * baseRadius;
        
        // Draw this segment as an independent arc
        ctx.beginPath();
        const segments = 60;
        for (let j = 0; j <= segments; j++) {
            const t = j / segments;
            // Original angle of the point on the circle
            const originalAngle = currentAngle + t * segmentAngleSize;
            
            // Original point on the circle
            const originalX = config.centerX + Math.cos(originalAngle) * baseRadius;
            const originalY = config.centerY + Math.sin(originalAngle) * baseRadius;
            
            // Apply self-rotation: rotate around the arc's center point (not the circle center)
            // Translate to center point, rotate, then translate back
            const dx = originalX - centerX;
            const dy = originalY - centerY;
            
            // Apply rotation matrix around the arc center point
            const cosRot = Math.cos(circleParams.selfRotation);
            const sinRot = Math.sin(circleParams.selfRotation);
            const rotatedX = dx * cosRot - dy * sinRot;
            const rotatedY = dx * sinRot + dy * cosRot;
            
            // Translate back
            const x = centerX + rotatedX;
            const y = centerY + rotatedY;
            
            if (j === 0) {
                ctx.moveTo(x, y);
            } else {
                ctx.lineTo(x, y);
            }
        }
        ctx.stroke();
        
        // Move to next segment position (with gap)
        currentAngle += segmentAngleSize + gapSize;
    }
}

function draw() {
    // Clear canvas
    ctx.fillStyle = 'black';
    ctx.fillRect(0, 0, width, height);
    
    // Draw the 4 nested circles
    const fourCircles = calculateFourCircles();
    const colors = ['magenta', 'white', 'cyan', 'green'];
    fourCircles.forEach((circle, index) => {
        drawCircleOutline(circle.cx, circle.cy, circle.radius, colors[index] || 'white');
    });
    
    // Draw outer segmented circles
    drawSegmentedCircle(5, params.outerCircle5);
    drawSegmentedCircle(6, params.outerCircle6);
    
    // Draw center point for reference
    ctx.fillStyle = 'red';
    ctx.beginPath();
    ctx.arc(config.centerX, config.centerY, 3, 0, Math.PI * 2);
    ctx.fill();
}

// Wait for DOM to be ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}
