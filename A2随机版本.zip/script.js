let canvas, ctx;
let width, height;

// Initial radius values (reference point for randomization)
const initialRadii = [0.15, 0.22, 0.31, 0.43]; // Circle 1, 2, 3, 4

// Parameters configuration
const params = {
    // Inner 4 circles - 根据用户给定的默认值
    innerCircles: [
        { radius: 0.15, offsetX: 0.02, offsetY: -0.02 },   // Circle 1: 15.0%, 2.00%, -2.00%
        { radius: 0.22, offsetX: 0.045, offsetY: 0.025 }, // Circle 2: 22.0%, 4.50%, 2.50%
        { radius: 0.31, offsetX: -0.035, offsetY: 0.025 }, // Circle 3: 31.0%, -3.50%, 2.50%
        { radius: 0.43, offsetX: 0.05, offsetY: 0.04 }   // Circle 4: 43.0%, 5.00%, 4.00%
    ],
    // Outer circle 5 (segmented petals)
    outerCircle5: {
        radius: 0.33,              // 33% as default
        segmentCount: 4,          // Number of segments (3-6)
        segmentLength: 0.0,       // Variation ratio (0-20%) relative to initial length
        selfRotation: 0.12,        // Self-rotation angle (radians)
        globalRotation: 0,         // Global rotation angle (radians)
    },
    // Outer circle 6 (segmented petals)
    outerCircle6: {
        radius: 0.44,              // 44% as default
        segmentCount: 4,           // Number of segments (3-6)
        segmentLength: 0.0,        // Variation ratio (0-20%) relative to initial length
        selfRotation: 0.12,        // Self-rotation angle (radians)
        globalRotation: 0.3927,    // ~22.5 degrees (Math.PI / 8)
    }
};

// Base configuration
const config = {
    maxRadius: 300,
    centerX: 0,
    centerY: 0,
};

function init() {
    canvas = document.getElementById('canvas');
    if (!canvas) {
        console.error('Canvas element not found!');
        return;
    }
    
    ctx = canvas.getContext('2d');
    if (!ctx) {
        console.error('Could not get 2D context!');
        return;
    }
    
    createControlPanel();
    setupRandomizeButton();
    resize();
    draw();
    console.log('Rose layout initialized successfully!');
}

function resize() {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
    config.centerX = width / 2;
    config.centerY = height / 2;
    config.maxRadius = Math.min(width, height) * 0.4;
}

window.addEventListener('resize', resize);

// Create control panel UI
function createControlPanel() {
    // Inner circles controls
    const innerControls = document.getElementById('innerCirclesControls');
    params.innerCircles.forEach((circle, index) => {
        const circleDiv = document.createElement('div');
        circleDiv.className = 'control-group';
        circleDiv.innerHTML = `
            <label>圆圈 ${index + 1} - 半径 (相对于最大半径):</label>
            <input type="range" id="innerR${index}" min="0.05" max="0.5" step="0.01" value="${circle.radius}">
            <span class="value-display" id="innerR${index}Value">${(circle.radius * 100).toFixed(1)}%</span>
            
            <label>圆圈 ${index + 1} - X偏移:</label>
            <input type="range" id="innerX${index}" min="-0.1" max="0.1" step="0.005" value="${circle.offsetX}">
            <span class="value-display" id="innerX${index}Value">${(circle.offsetX * 100).toFixed(2)}%</span>
            
            <label>圆圈 ${index + 1} - Y偏移:</label>
            <input type="range" id="innerY${index}" min="-0.1" max="0.1" step="0.005" value="${circle.offsetY}">
            <span class="value-display" id="innerY${index}Value">${(circle.offsetY * 100).toFixed(2)}%</span>
        `;
        innerControls.appendChild(circleDiv);
        
        // Add event listeners
        document.getElementById(`innerR${index}`).addEventListener('input', (e) => {
            params.innerCircles[index].radius = parseFloat(e.target.value);
            document.getElementById(`innerR${index}Value`).textContent = (params.innerCircles[index].radius * 100).toFixed(1) + '%';
            draw();
        });
        document.getElementById(`innerX${index}`).addEventListener('input', (e) => {
            params.innerCircles[index].offsetX = parseFloat(e.target.value);
            document.getElementById(`innerX${index}Value`).textContent = (params.innerCircles[index].offsetX * 100).toFixed(2) + '%';
            draw();
        });
        document.getElementById(`innerY${index}`).addEventListener('input', (e) => {
            params.innerCircles[index].offsetY = parseFloat(e.target.value);
            document.getElementById(`innerY${index}Value`).textContent = (params.innerCircles[index].offsetY * 100).toFixed(2) + '%';
            draw();
        });
    });
    
    // Outer circle 5 controls
    const outer5Controls = document.getElementById('outerCircle5Controls');
    outer5Controls.innerHTML = `
        <div class="control-group">
            <label>半径 (相对于最大半径):</label>
            <input type="range" id="outer5Radius" min="0.3" max="0.9" step="0.01" value="${params.outerCircle5.radius}">
            <span class="value-display" id="outer5RadiusValue">${(params.outerCircle5.radius * 100).toFixed(1)}%</span>
        </div>
        <div class="control-group">
            <label>分段数量:</label>
            <input type="range" id="outer5SegmentCount" min="3" max="6" step="1" value="${params.outerCircle5.segmentCount}">
            <span class="value-display" id="outer5SegmentCountValue">${params.outerCircle5.segmentCount}</span>
        </div>
        <div class="control-group">
            <label>每段长度 (变化比例):</label>
            <input type="range" id="outer5Segment" min="0" max="0.2" step="0.01" value="${params.outerCircle5.segmentLength}">
            <span class="value-display" id="outer5SegmentValue">${(() => {
                const initialUnit = 1.0 / params.outerCircle5.segmentCount;
                const actualLength = initialUnit * (1 + params.outerCircle5.segmentLength);
                return (params.outerCircle5.segmentLength * 100).toFixed(1) + '% (实际: ' + (actualLength * 100).toFixed(1) + '%)';
            })()}</span>
        </div>
        <div class="control-group">
            <label>自旋角 (弧度):</label>
            <input type="range" id="outer5SelfRot" min="-0.5" max="0.5" step="0.01" value="${params.outerCircle5.selfRotation}">
            <span class="value-display" id="outer5SelfRotValue">${params.outerCircle5.selfRotation.toFixed(3)}</span>
        </div>
        <div class="control-group">
            <label>整体旋转角 (弧度):</label>
            <input type="range" id="outer5GlobalRot" min="0" max="6.28" step="0.01" value="${params.outerCircle5.globalRotation}">
            <span class="value-display" id="outer5GlobalRotValue">${params.outerCircle5.globalRotation.toFixed(3)}</span>
        </div>
    `;
    
    document.getElementById('outer5Radius').addEventListener('input', (e) => {
        params.outerCircle5.radius = parseFloat(e.target.value);
        document.getElementById('outer5RadiusValue').textContent = (params.outerCircle5.radius * 100).toFixed(1) + '%';
        draw();
    });
    document.getElementById('outer5SegmentCount').addEventListener('input', (e) => {
        params.outerCircle5.segmentCount = parseInt(e.target.value);
        document.getElementById('outer5SegmentCountValue').textContent = params.outerCircle5.segmentCount;
        // Update segment length display when count changes
        const initialUnit = 1.0 / params.outerCircle5.segmentCount;
        const actualLength = initialUnit * (1 + params.outerCircle5.segmentLength);
        document.getElementById('outer5SegmentValue').textContent = (params.outerCircle5.segmentLength * 100).toFixed(1) + '% (实际: ' + (actualLength * 100).toFixed(1) + '%)';
        draw();
    });
    document.getElementById('outer5Segment').addEventListener('input', (e) => {
        params.outerCircle5.segmentLength = parseFloat(e.target.value);
        const initialUnit = 1.0 / params.outerCircle5.segmentCount;
        const actualLength = initialUnit * (1 + params.outerCircle5.segmentLength);
        document.getElementById('outer5SegmentValue').textContent = (params.outerCircle5.segmentLength * 100).toFixed(1) + '% (实际: ' + (actualLength * 100).toFixed(1) + '%)';
        draw();
    });
    document.getElementById('outer5SelfRot').addEventListener('input', (e) => {
        params.outerCircle5.selfRotation = parseFloat(e.target.value);
        document.getElementById('outer5SelfRotValue').textContent = params.outerCircle5.selfRotation.toFixed(3);
        draw();
    });
    document.getElementById('outer5GlobalRot').addEventListener('input', (e) => {
        params.outerCircle5.globalRotation = parseFloat(e.target.value);
        document.getElementById('outer5GlobalRotValue').textContent = params.outerCircle5.globalRotation.toFixed(3);
        draw();
    });
    
    // Outer circle 6 controls
    const outer6Controls = document.getElementById('outerCircle6Controls');
    outer6Controls.innerHTML = `
        <div class="control-group">
            <label>半径 (相对于最大半径):</label>
            <input type="range" id="outer6Radius" min="0.3" max="0.9" step="0.01" value="${params.outerCircle6.radius}">
            <span class="value-display" id="outer6RadiusValue">${(params.outerCircle6.radius * 100).toFixed(1)}%</span>
        </div>
        <div class="control-group">
            <label>分段数量:</label>
            <input type="range" id="outer6SegmentCount" min="3" max="6" step="1" value="${params.outerCircle6.segmentCount}">
            <span class="value-display" id="outer6SegmentCountValue">${params.outerCircle6.segmentCount}</span>
        </div>
        <div class="control-group">
            <label>每段长度 (变化比例):</label>
            <input type="range" id="outer6Segment" min="0" max="0.2" step="0.01" value="${params.outerCircle6.segmentLength}">
            <span class="value-display" id="outer6SegmentValue">${(() => {
                const initialUnit = 1.0 / params.outerCircle6.segmentCount;
                const actualLength = initialUnit * (1 + params.outerCircle6.segmentLength);
                return (params.outerCircle6.segmentLength * 100).toFixed(1) + '% (实际: ' + (actualLength * 100).toFixed(1) + '%)';
            })()}</span>
        </div>
        <div class="control-group">
            <label>自旋角 (弧度):</label>
            <input type="range" id="outer6SelfRot" min="-0.5" max="0.5" step="0.01" value="${params.outerCircle6.selfRotation}">
            <span class="value-display" id="outer6SelfRotValue">${params.outerCircle6.selfRotation.toFixed(3)}</span>
        </div>
        <div class="control-group">
            <label>整体旋转角 (弧度):</label>
            <input type="range" id="outer6GlobalRot" min="0" max="6.28" step="0.01" value="${params.outerCircle6.globalRotation}">
            <span class="value-display" id="outer6GlobalRotValue">${params.outerCircle6.globalRotation.toFixed(3)}</span>
        </div>
    `;
    
    document.getElementById('outer6Radius').addEventListener('input', (e) => {
        params.outerCircle6.radius = parseFloat(e.target.value);
        document.getElementById('outer6RadiusValue').textContent = (params.outerCircle6.radius * 100).toFixed(1) + '%';
        draw();
    });
    document.getElementById('outer6SegmentCount').addEventListener('input', (e) => {
        params.outerCircle6.segmentCount = parseInt(e.target.value);
        document.getElementById('outer6SegmentCountValue').textContent = params.outerCircle6.segmentCount;
        // Update segment length display when count changes
        const initialUnit = 1.0 / params.outerCircle6.segmentCount;
        const actualLength = initialUnit * (1 + params.outerCircle6.segmentLength);
        document.getElementById('outer6SegmentValue').textContent = (params.outerCircle6.segmentLength * 100).toFixed(1) + '% (实际: ' + (actualLength * 100).toFixed(1) + '%)';
        draw();
    });
    document.getElementById('outer6Segment').addEventListener('input', (e) => {
        params.outerCircle6.segmentLength = parseFloat(e.target.value);
        const initialUnit = 1.0 / params.outerCircle6.segmentCount;
        const actualLength = initialUnit * (1 + params.outerCircle6.segmentLength);
        document.getElementById('outer6SegmentValue').textContent = (params.outerCircle6.segmentLength * 100).toFixed(1) + '% (实际: ' + (actualLength * 100).toFixed(1) + '%)';
        draw();
    });
    document.getElementById('outer6SelfRot').addEventListener('input', (e) => {
        params.outerCircle6.selfRotation = parseFloat(e.target.value);
        document.getElementById('outer6SelfRotValue').textContent = params.outerCircle6.selfRotation.toFixed(3);
        draw();
    });
    document.getElementById('outer6GlobalRot').addEventListener('input', (e) => {
        params.outerCircle6.globalRotation = parseFloat(e.target.value);
        document.getElementById('outer6GlobalRotValue').textContent = params.outerCircle6.globalRotation.toFixed(3);
        draw();
    });
}

// Setup randomize button
function setupRandomizeButton() {
    const button = document.getElementById('randomizeButton');
    button.addEventListener('click', randomizeInnerCircles);
}

// Randomize inner circles with tangent constraint
// First randomize sizes (±20% from initial values), then calculate positions
function randomizeInnerCircles() {
    const maxRadius = config.maxRadius * 0.5;
    
    // Step 1: Randomize circle sizes first
    // Circle 4: ±10%, Circles 1-3: ±15%
    params.innerCircles.forEach((circle, index) => {
        const initialRadius = initialRadii[index];
        // Circle 4 (index 3) uses 10% variation, others use 15%
        const variationRange = index === 3 ? 0.1 : 0.15; // 10% for circle 4, 15% for others
        const variation = (Math.random() - 0.5) * (variationRange * 2); // -range to +range
        const newRadius = initialRadius * (1 + variation);
        // Clamp to reasonable bounds (5% to 50% of maxRadius)
        params.innerCircles[index].radius = Math.max(0.05, Math.min(0.5, newRadius));
    });
    
    // Step 2: Calculate positions based on new radii
    // Circle 4: Fixed at center, radius is now randomized
    const r4 = maxRadius * params.innerCircles[3].radius;
    params.innerCircles[3].offsetX = 0;
    params.innerCircles[3].offsetY = 0;
    
    // Circle 3: Rolls inside Circle 4, tangent to Circle 4
    // Distance from center = r4 - r3
    const r3 = maxRadius * params.innerCircles[2].radius;
    // Ensure r3 is smaller than r4 for proper nesting
    const actualR3 = Math.min(r3, r4 * 0.99);
    const dist3 = Math.max(0, r4 - actualR3); // Ensure non-negative
    const angle3 = Math.random() * Math.PI * 2;
    params.innerCircles[2].offsetX = (dist3 * Math.cos(angle3)) / maxRadius;
    params.innerCircles[2].offsetY = (dist3 * Math.sin(angle3)) / maxRadius;
    
    // Circle 2: Rolls inside Circle 3, tangent to Circle 3
    // Distance from Circle 3's center = r3 - r2
    const r2 = maxRadius * params.innerCircles[1].radius;
    const actualR2 = Math.min(r2, actualR3 * 0.99);
    const dist2 = Math.max(0, actualR3 - actualR2);
    const angle2 = Math.random() * Math.PI * 2;
    // Calculate Circle 3's center position
    const c3X = maxRadius * params.innerCircles[2].offsetX;
    const c3Y = maxRadius * params.innerCircles[2].offsetY;
    // Circle 2's center relative to Circle 3's center
    params.innerCircles[1].offsetX = (c3X + dist2 * Math.cos(angle2)) / maxRadius;
    params.innerCircles[1].offsetY = (c3Y + dist2 * Math.sin(angle2)) / maxRadius;
    
    // Circle 1: Rolls inside Circle 2, tangent to Circle 2
    // Distance from Circle 2's center = r2 - r1
    const r1 = maxRadius * params.innerCircles[0].radius;
    const actualR1 = Math.min(r1, actualR2 * 0.99);
    const dist1 = Math.max(0, actualR2 - actualR1);
    const angle1 = Math.random() * Math.PI * 2;
    // Calculate Circle 2's center position
    const c2X = maxRadius * params.innerCircles[1].offsetX;
    const c2Y = maxRadius * params.innerCircles[1].offsetY;
    // Circle 1's center relative to Circle 2's center
    params.innerCircles[0].offsetX = (c2X + dist1 * Math.cos(angle1)) / maxRadius;
    params.innerCircles[0].offsetY = (c2Y + dist1 * Math.sin(angle1)) / maxRadius;
    
    // Update UI sliders to reflect new values
    params.innerCircles.forEach((circle, index) => {
        const rSlider = document.getElementById(`innerR${index}`);
        const xSlider = document.getElementById(`innerX${index}`);
        const ySlider = document.getElementById(`innerY${index}`);
        
        if (rSlider) {
            rSlider.value = circle.radius;
            document.getElementById(`innerR${index}Value`).textContent = (circle.radius * 100).toFixed(1) + '%';
        }
        if (xSlider) {
            xSlider.value = circle.offsetX;
            document.getElementById(`innerX${index}Value`).textContent = (circle.offsetX * 100).toFixed(2) + '%';
        }
        if (ySlider) {
            ySlider.value = circle.offsetY;
            document.getElementById(`innerY${index}Value`).textContent = (circle.offsetY * 100).toFixed(2) + '%';
        }
    });
    
    // Step 3: Randomize outer circles (5 and 6)
    randomizeOuterCircles();
    
    // Redraw
    draw();
}

// Randomize outer circles 5 and 6
function randomizeOuterCircles() {
    // Step 1: Randomize segment counts
    // Circle 5: random between 3-5
    const segmentCount5 = 3 + Math.floor(Math.random() * 3); // 3, 4, or 5
    params.outerCircle5.segmentCount = segmentCount5;
    
    // Circle 6: random between a (Circle 5's count) to 6
    const segmentCount6 = segmentCount5 + Math.floor(Math.random() * (7 - segmentCount5)); // a to 6 (inclusive)
    params.outerCircle6.segmentCount = segmentCount6;
    
    // Step 2: Randomize Circle 5 parameters
    // 1. Segment length variation: 4% to 10%
    params.outerCircle5.segmentLength = 0.04 + Math.random() * 0.06; // 0.04 to 0.10
    // 2. Self-rotation: 0.1 to 0.13
    params.outerCircle5.selfRotation = 0.1 + Math.random() * 0.03; // 0.1 to 0.13
    // 3. Global rotation: 0 to 2π (any angle)
    params.outerCircle5.globalRotation = Math.random() * Math.PI * 2;
    
    // Step 3: Randomize Circle 6 parameters
    // 1. Segment length variation: 4% to 10%
    params.outerCircle6.segmentLength = 0.04 + Math.random() * 0.06; // 0.04 to 0.10
    // 2. Self-rotation: 0.1 to 0.13
    params.outerCircle6.selfRotation = 0.1 + Math.random() * 0.03; // 0.1 to 0.13
    // 3. Global rotation: 0 to 2π (any angle)
    params.outerCircle6.globalRotation = Math.random() * Math.PI * 2;
    
    // Update UI sliders for Circle 5
    const outer5SegmentCount = document.getElementById('outer5SegmentCount');
    const outer5Segment = document.getElementById('outer5Segment');
    const outer5SelfRot = document.getElementById('outer5SelfRot');
    const outer5GlobalRot = document.getElementById('outer5GlobalRot');
    
    if (outer5SegmentCount) {
        outer5SegmentCount.value = params.outerCircle5.segmentCount;
        document.getElementById('outer5SegmentCountValue').textContent = params.outerCircle5.segmentCount;
    }
    if (outer5Segment) {
        outer5Segment.value = params.outerCircle5.segmentLength;
        const initialUnit5 = 1.0 / params.outerCircle5.segmentCount;
        const actualLength5 = initialUnit5 * (1 + params.outerCircle5.segmentLength);
        document.getElementById('outer5SegmentValue').textContent = (params.outerCircle5.segmentLength * 100).toFixed(1) + '% (实际: ' + (actualLength5 * 100).toFixed(1) + '%)';
    }
    if (outer5SelfRot) {
        outer5SelfRot.value = params.outerCircle5.selfRotation;
        document.getElementById('outer5SelfRotValue').textContent = params.outerCircle5.selfRotation.toFixed(3);
    }
    if (outer5GlobalRot) {
        outer5GlobalRot.value = params.outerCircle5.globalRotation;
        document.getElementById('outer5GlobalRotValue').textContent = params.outerCircle5.globalRotation.toFixed(3);
    }
    
    // Update UI sliders for Circle 6
    const outer6SegmentCount = document.getElementById('outer6SegmentCount');
    const outer6Segment = document.getElementById('outer6Segment');
    const outer6SelfRot = document.getElementById('outer6SelfRot');
    const outer6GlobalRot = document.getElementById('outer6GlobalRot');
    
    if (outer6SegmentCount) {
        outer6SegmentCount.value = params.outerCircle6.segmentCount;
        document.getElementById('outer6SegmentCountValue').textContent = params.outerCircle6.segmentCount;
    }
    if (outer6Segment) {
        outer6Segment.value = params.outerCircle6.segmentLength;
        const initialUnit6 = 1.0 / params.outerCircle6.segmentCount;
        const actualLength6 = initialUnit6 * (1 + params.outerCircle6.segmentLength);
        document.getElementById('outer6SegmentValue').textContent = (params.outerCircle6.segmentLength * 100).toFixed(1) + '% (实际: ' + (actualLength6 * 100).toFixed(1) + '%)';
    }
    if (outer6SelfRot) {
        outer6SelfRot.value = params.outerCircle6.selfRotation;
        document.getElementById('outer6SelfRotValue').textContent = params.outerCircle6.selfRotation.toFixed(3);
    }
    if (outer6GlobalRot) {
        outer6GlobalRot.value = params.outerCircle6.globalRotation;
        document.getElementById('outer6GlobalRotValue').textContent = params.outerCircle6.globalRotation.toFixed(3);
    }
}

// Calculate positions for 4 nested circles using parameters
function calculateFourCircles() {
    const maxRadius = config.maxRadius * 0.5;
    const circles = [];
    
    params.innerCircles.forEach((circleParams, index) => {
        const radius = maxRadius * circleParams.radius;
        const offsetX = maxRadius * circleParams.offsetX;
        const offsetY = maxRadius * circleParams.offsetY;
        
        circles.push({
            cx: config.centerX + offsetX,
            cy: config.centerY + offsetY,
            radius: radius
        });
    });
    
    return circles;
}

// Draw a circle as line segments
function drawCircleOutline(cx, cy, radius, color = 'white') {
    ctx.strokeStyle = color;
    ctx.lineWidth = 1;
    ctx.beginPath();
    
    const segments = 120;
    for (let i = 0; i <= segments; i++) {
        const angle = (i / segments) * Math.PI * 2;
        const x = cx + Math.cos(angle) * radius;
        const y = cy + Math.sin(angle) * radius;
        
        if (i === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
    }
    
    ctx.stroke();
}

// Draw segmented circle with parameters
function drawSegmentedCircle(circleIndex, circleParams) {
    const numSegments = circleParams.segmentCount; // Use dynamic segment count
    const baseRadius = config.maxRadius * circleParams.radius;
    
    // Calculate actual segment length based on variation ratio
    // Initial unit = 100% / segmentCount (e.g., 4 segments = 25%, 5 segments = 20%)
    const initialUnit = 1.0 / numSegments; // As a ratio (0.25 for 4 segments, 0.2 for 5 segments)
    // Actual segment length = initial unit * (1 + variation ratio)
    // segmentLength is now a variation ratio (0-0.2, i.e., 0-20%)
    const actualSegmentLength = initialUnit * (1 + circleParams.segmentLength);
    const segmentAngleSize = actualSegmentLength * Math.PI * 2; // Convert to radians
    const gapSize = (Math.PI * 2 - segmentAngleSize * numSegments) / numSegments; // Calculate gap
    
    ctx.strokeStyle = circleIndex === 5 ? 'cyan' : 'yellow';
    ctx.lineWidth = 2;
    
    // Start from global rotation angle
    let currentAngle = circleParams.globalRotation;
    
    for (let i = 0; i < numSegments; i++) {
        // Calculate segment midpoint angle (the center point of this arc on the circle)
        const segmentMidAngle = currentAngle + segmentAngleSize * 0.5;
        
        // Calculate the center point of the arc on the circle (this is the rotation center for self-rotation)
        const centerX = config.centerX + Math.cos(segmentMidAngle) * baseRadius;
        const centerY = config.centerY + Math.sin(segmentMidAngle) * baseRadius;
        
        // Draw this segment as an independent arc
        ctx.beginPath();
        const segments = 60;
        for (let j = 0; j <= segments; j++) {
            const t = j / segments;
            // Original angle of the point on the circle
            const originalAngle = currentAngle + t * segmentAngleSize;
            
            // Original point on the circle
            const originalX = config.centerX + Math.cos(originalAngle) * baseRadius;
            const originalY = config.centerY + Math.sin(originalAngle) * baseRadius;
            
            // Apply self-rotation: rotate around the arc's center point (not the circle center)
            // Translate to center point, rotate, then translate back
            const dx = originalX - centerX;
            const dy = originalY - centerY;
            
            // Apply rotation matrix around the arc center point
            const cosRot = Math.cos(circleParams.selfRotation);
            const sinRot = Math.sin(circleParams.selfRotation);
            const rotatedX = dx * cosRot - dy * sinRot;
            const rotatedY = dx * sinRot + dy * cosRot;
            
            // Translate back
            const x = centerX + rotatedX;
            const y = centerY + rotatedY;
            
            if (j === 0) {
                ctx.moveTo(x, y);
            } else {
                ctx.lineTo(x, y);
            }
        }
        ctx.stroke();
        
        // Move to next segment position (with gap)
        currentAngle += segmentAngleSize + gapSize;
    }
}

function draw() {
    // Clear canvas
    ctx.fillStyle = 'black';
    ctx.fillRect(0, 0, width, height);
    
    // Draw the 4 nested circles
    const fourCircles = calculateFourCircles();
    const colors = ['magenta', 'white', 'cyan', 'green'];
    fourCircles.forEach((circle, index) => {
        drawCircleOutline(circle.cx, circle.cy, circle.radius, colors[index] || 'white');
    });
    
    // Draw outer segmented circles
    drawSegmentedCircle(5, params.outerCircle5);
    drawSegmentedCircle(6, params.outerCircle6);
    
    // Draw center point for reference
    ctx.fillStyle = 'red';
    ctx.beginPath();
    ctx.arc(config.centerX, config.centerY, 3, 0, Math.PI * 2);
    ctx.fill();
}

// Wait for DOM to be ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}
